stm32flash 0.7 binaries

The stm32flash.exe binary is for Microsoft Windows 64-bit
It was built using MinGW on Ubuntu 20.04

The stm32flash_macos binary is for macOS (Mach-O 64-bit x86_64)
It was built on macOS 11.6.1

The stm32flash_linux binary was build on Ubuntu 20.04 and might
or might not work on other distributions

For build instructions please see:
https://sourceforge.net/p/stm32flash/wiki/Build/

Source code repository:
https://sourceforge.net/p/stm32flash/code/ci/v0.7/tree/
